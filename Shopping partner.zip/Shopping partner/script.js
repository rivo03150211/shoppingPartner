var inputItems = document.getElementById("inputItem");
var inputDollar = document.getElementById("inputDollar");
var inputQuantity = document.getElementById("inputQuantity");
var submitBtn = document.getElementById("btnSubmit");
var countPara = document.getElementById("countsPara");

var countItems = 0;

function myFuction(e) {
  e.preventDefault();
 

  //For Items

  if (
    inputItems.value == "" ||
    inputDollar.value == "" ||
    inputQuantity.value == ""
  ) {

    alert("Please put proper info");
  }

  else {
    var list = document.getElementById("items");
    var listItem = document.createElement("li");
    listItem.innerText = inputItems.value;
    listItem.classList.add("list-group-item", "list-group-item-action");
    list.appendChild(listItem);
    inputItems.value = "";

    //For Quantity

    var quantity = document.getElementById("quantity");
    var listQuantity = document.createElement("li");
    listQuantity.innerText = `${inputQuantity.value} KG`;
    listQuantity.classList.add("list-group-item", "list-group-item-action");
    quantity.appendChild(listQuantity);
    inputQuantity.value = "";

    //For Dollar

    var price = document.getElementById("price");
    var listprice = document.createElement("li");
    listprice.innerText = `$ ${inputDollar.value}`;
    listprice.classList.add("list-group-item", "list-group-item-action");
    price.appendChild(listprice);
    inputDollar.value = "";


    var finishBtn = document.getElementById("finishBtn");
    finishBtn.addEventListener("click", ()=>{

      countPara.style.visibility = "visible";
      countItems += 1;
      countPara.innerText = `The number of item that you've bought is "${countItems}"`;
    });
  
    var clearBtn = document.getElementById("clearBtn")
    clearBtn.addEventListener("click", () => {
      list.removeChild(listItem);
      quantity.removeChild(listQuantity);
      price.removeChild(listprice);
      countPara.style.visibility = "hidden";
    });

  }
}

submitBtn.addEventListener("click", myFuction);
